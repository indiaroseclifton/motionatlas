Phosphor / Thin
===============

300 SVG icons chosen for common interface use.
Source: @phosphor-icons/core@2.1.1 (https://www.npmjs.com/package/@phosphor-icons/core/v/2.1.1)
Project: https://phosphoricons.com
Licence: MIT (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
The SVGs use currentColor, so they take the text colour they sit in.
