Tabler / Outline
================

300 SVG icons chosen for common interface use.
Source: @tabler/icons@3.49.0 (https://www.npmjs.com/package/@tabler/icons/v/3.49.0)
Project: https://tabler.io/icons
Licence: MIT (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
The SVGs use currentColor, so they take the text colour they sit in.
