Line MD / Animated line: 12 specimen icons.
Source: @iconify-json/line-md@1.2.16
Licence: MIT (see LICENSE.txt)
