OpenMoji / Colour pictograms
============================

300 SVG icons chosen for common interface use.
Source: openmoji@17.0.0 (https://www.npmjs.com/package/openmoji/v/17.0.0)
Project: https://openmoji.org
Licence: CC BY-SA 4.0 (see LICENSE.txt)

All emojis designed by OpenMoji, the open-source emoji and icon project. License: CC BY-SA 4.0.
Attribution: OpenMoji (https://openmoji.org), CC BY-SA 4.0. SVGs here are minified (whitespace, comments
and unused ids removed; no visual change). Adapted versions stay under CC BY-SA 4.0.

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
