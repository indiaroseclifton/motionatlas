Simple Icons / Brand logos
==========================

300 SVG icons chosen for common interface use.
Source: @iconify-json/simple-icons@1.2.102 (https://www.npmjs.com/package/@iconify-json/simple-icons/v/1.2.102)
Project: https://simpleicons.org
Licence: CC0 1.0 (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
The SVGs use currentColor, so they take the text colour they sit in.
