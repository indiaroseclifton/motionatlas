Material Symbols / Rounded: 13 specimen icons.
Source: @iconify-json/material-symbols@1.2.99
Licence: Apache 2.0 (see LICENSE.txt)
