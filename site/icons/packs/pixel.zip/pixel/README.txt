Pixelarticons / Pixel
=====================

300 SVG icons chosen for common interface use.
Source: pixelarticons@2.4.2 (https://www.npmjs.com/package/pixelarticons/v/2.4.2)
Project: https://pixelarticons.com
Licence: MIT (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
The SVGs use currentColor, so they take the text colour they sit in.
