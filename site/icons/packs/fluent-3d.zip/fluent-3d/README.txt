Fluent Emoji / 3D
=================

120 PNG icons chosen for common interface use.
Source: microsoft/fluentui-emoji (GitHub, main branch) (https://github.com/microsoft/fluentui-emoji)
Project: https://github.com/microsoft/fluentui-emoji
Licence: MIT (see LICENSE.txt)

PNG renders resized to 192 px from the 3D style of Microsoft Fluent Emoji.

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
