fluent-3d specimen pack from the Visual & Motion Atlas
Source: Microsoft Fluent UI Emoji 3D (resized to 192px) / MIT / https://github.com/microsoft/fluentui-emoji
13 icons: bell.png, bookmark-simple.png, calendar-blank.png, check-circle.png, folder.png, gear.png, heart.png, house.png, magnifying-glass.png, plus.png, squares-four.png, upload-simple.png, user.png
The full library and official downloads are at the source link above.
