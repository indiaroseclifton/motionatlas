Solar / Bold duotone
====================

300 SVG icons chosen for common interface use.
Source: @iconify-json/solar@1.2.15 (https://www.npmjs.com/package/@iconify-json/solar/v/1.2.15)
Project: https://www.figma.com/community/file/1166831539721848736
Licence: CC BY 4.0 (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
The SVGs use currentColor, so they take the text colour they sit in.
