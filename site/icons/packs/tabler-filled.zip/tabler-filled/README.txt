Tabler / Filled
===============

900 SVG icons.
Source: @tabler/icons@3.49.0 (https://www.npmjs.com/package/@tabler/icons/v/3.49.0)
Project: https://tabler.io/icons
Licence: MIT (see LICENSE.txt)

Built by tools/icons-more.py for the Visual & Motion Atlas. The SVGs use currentColor, so they take the
text colour they sit in.
