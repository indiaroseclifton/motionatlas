Flat Color Icons / Flat colour
==============================

300 SVG icons chosen for common interface use.
Source: @iconify-json/flat-color-icons@1.2.3 (https://www.npmjs.com/package/@iconify-json/flat-color-icons/v/1.2.3)
Project: https://icons8.com/icons/color
Licence: MIT (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
