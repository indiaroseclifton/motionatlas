Icon Park / Two-tone colour
===========================

300 SVG icons chosen for common interface use.
Source: @iconify-json/icon-park@1.2.4 (https://www.npmjs.com/package/@iconify-json/icon-park/v/1.2.4)
Project: https://iconpark.oceanengine.com
Licence: Apache 2.0 (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
