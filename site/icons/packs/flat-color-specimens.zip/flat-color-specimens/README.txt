Flat Color Icons / Flat colour: 13 specimen icons.
Source: @iconify-json/flat-color-icons@1.2.3
Licence: MIT (see LICENSE.txt)
