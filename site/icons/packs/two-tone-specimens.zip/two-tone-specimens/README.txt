Icon Park / Two-tone colour: 13 specimen icons.
Source: @iconify-json/icon-park@1.2.4
Licence: Apache 2.0 (see LICENSE.txt)
