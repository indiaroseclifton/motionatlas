Simple Icons / Brand logos: 13 specimen icons.
Source: @iconify-json/simple-icons@1.2.102
Licence: CC0 1.0 (see LICENSE.txt)
