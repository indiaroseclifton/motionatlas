Pepicons / Pencil: 13 specimen icons.
Source: @iconify-json/pepicons-pencil@1.2.4
Licence: CC BY 4.0 (see LICENSE.txt)
