Heroicons / Outline
===================

324 SVG icons chosen for common interface use.
Source: heroicons@2.2.0 (https://www.npmjs.com/package/heroicons/v/2.2.0)
Project: https://heroicons.com
Licence: MIT (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
The SVGs use currentColor, so they take the text colour they sit in.
