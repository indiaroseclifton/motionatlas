Game Icons / Illustrative: 10 specimen icons.
Source: @iconify-json/game-icons@1.2.4
Licence: CC BY 3.0 (see LICENSE.txt)
