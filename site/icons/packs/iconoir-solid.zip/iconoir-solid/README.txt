Iconoir / Solid
===============

288 SVG icons.
Source: iconoir@7.12.2 (https://www.npmjs.com/package/iconoir/v/7.12.2)
Project: https://iconoir.com
Licence: MIT (see LICENSE.txt)

Built by tools/icons-more.py for the Visual & Motion Atlas. The SVGs use currentColor, so they take the
text colour they sit in.
