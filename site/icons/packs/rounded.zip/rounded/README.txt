Material Symbols / Rounded
==========================

300 SVG icons chosen for common interface use.
Source: @iconify-json/material-symbols@1.2.99 (https://www.npmjs.com/package/@iconify-json/material-symbols/v/1.2.99)
Project: https://fonts.google.com/icons
Licence: Apache 2.0 (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
The SVGs use currentColor, so they take the text colour they sit in.
