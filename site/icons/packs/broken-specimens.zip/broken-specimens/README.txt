Solar / Broken line: 13 specimen icons.
Source: @iconify-json/solar@1.2.15
Licence: CC BY 4.0 (see LICENSE.txt)
