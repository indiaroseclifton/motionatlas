Game Icons / Illustrative
=========================

300 SVG icons chosen for common interface use.
Source: @iconify-json/game-icons@1.2.4 (https://www.npmjs.com/package/@iconify-json/game-icons/v/1.2.4)
Project: https://game-icons.net
Licence: CC BY 3.0 (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
The SVGs use currentColor, so they take the text colour they sit in.
