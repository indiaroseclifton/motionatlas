thin specimen pack from the Visual & Motion Atlas
Source: Phosphor Icons 2.1.1 (thin) / MIT / https://phosphoricons.com
13 icons: bell.svg, bookmark-simple.svg, calendar-blank.svg, check-circle.svg, folder.svg, gear.svg, heart.svg, house.svg, magnifying-glass.svg, plus.svg, squares-four.svg, upload-simple.svg, user.svg
The full library and official downloads are at the source link above.
