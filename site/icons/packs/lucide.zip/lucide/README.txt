Lucide / Outline
================

300 SVG icons chosen for common interface use.
Source: lucide-static@1.59.0 (https://www.npmjs.com/package/lucide-static/v/1.59.0)
Project: https://lucide.dev
Licence: ISC (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
The SVGs use currentColor, so they take the text colour they sit in.
