Lucide / Outline
================

1500 SVG icons.
Source: lucide-static@1.59.0 (https://www.npmjs.com/package/lucide-static/v/1.59.0)
Project: https://lucide.dev
Licence: ISC (see LICENSE.txt)

Built by tools/icons-more.py for the Visual & Motion Atlas. The SVGs use currentColor, so they take the
text colour they sit in.
