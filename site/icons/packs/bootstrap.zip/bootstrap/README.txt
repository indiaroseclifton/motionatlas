Bootstrap Icons / Outline
=========================

1300 SVG icons.
Source: bootstrap-icons@1.13.2 (https://www.npmjs.com/package/bootstrap-icons/v/1.13.2)
Project: https://icons.getbootstrap.com
Licence: MIT (see LICENSE.txt)

Built by tools/icons-more.py for the Visual & Motion Atlas. The SVGs use currentColor, so they take the
text colour they sit in.
