Line MD / Animated line
=======================

300 SVG icons chosen for common interface use.
Source: @iconify-json/line-md@1.2.16 (https://www.npmjs.com/package/@iconify-json/line-md/v/1.2.16)
Project: https://github.com/cyberalien/line-md
Licence: MIT (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
The SVGs use currentColor, so they take the text colour they sit in.
