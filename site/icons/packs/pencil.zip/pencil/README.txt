Pepicons / Pencil
=================

300 SVG icons chosen for common interface use.
Source: @iconify-json/pepicons-pencil@1.2.4 (https://www.npmjs.com/package/@iconify-json/pepicons-pencil/v/1.2.4)
Project: https://pepicons.com
Licence: CC BY 4.0 (see LICENSE.txt)

Built by tools/icons.py for the Visual & Motion Atlas. icons.json lists every name with its
search keywords.
The SVGs use currentColor, so they take the text colour they sit in.
